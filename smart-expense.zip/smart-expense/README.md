# 🧾 智能记账 App (Smart Expense Tracker)

> "说一句话或拍张照，自动帮你记账"

一款面向年轻白领和家庭用户的智能记账应用，采用 Monorepo 全栈架构，支持 AI 智能录入、家庭共享、多维统计分析和数据导出。

---

## 🎯 核心功能

| 功能 | 描述 |
|------|------|
| **智能录入** | 自然语言文本输入（如"今天午饭花了35"），AI 自动解析为记账条目 |
| **账单编辑** | 点击最近账单中任意一条即可打开编辑面板，修改金额 / 类别 / 类型 / 备注 / 日期，或直接删除 |
| **家庭共享** | 创建家庭组，多成员独立记账，数据实时同步，权限管理（管理员/成员/只读） |
| **多维统计** | AI 智能洞察、收支趋势图、类别占比图、成员对比柱状图 |
| **数据导出** | 支持 CSV 导出，分享卡片生成 |

---

## 💻 技术栈

| 层级 | 技术 |
|------|------|
| **项目架构** | Monorepo (NPM Workspaces) |
| **移动端** | React Native (Expo) + React Navigation |
| **后端** | Node.js + Express + TypeScript |
| **数据库** | SQLite (better-sqlite3) |
| **AI 解析** | 规则引擎 + OpenAI API (可选增强) |
| **状态管理** | Zustand |
| **认证** | JWT (jsonwebtoken + bcryptjs) |

---

## 📂 项目结构

```
smart-expense/
├── apps/
│   ├── mobile/                # React Native (Expo) 前端
│   │   ├── src/
│   │   │   ├── screens/       # 5个Tab页面
│   │   │   ├── components/    # 共享组件
│   │   │   ├── navigation/    # 路由导航
│   │   │   ├── services/      # API 调用层
│   │   │   ├── stores/        # Zustand 状态管理
│   │   │   └── constants/     # 主题配置
│   │   ├── App.tsx
│   │   └── app.json
│   └── server/                # Node.js + Express 后端
│       ├── src/
│       │   ├── routes/        # API 路由 (auth, records, categories, families, parse, budgets, export)
│       │   ├── services/      # AI 解析引擎
│       │   ├── middlewares/   # 认证、错误处理
│       │   ├── database.ts    # SQLite 数据库管理
│       │   ├── seed.ts        # 种子数据
│       │   └── index.ts       # 入口文件
│       └── data/              # SQLite 数据库文件
├── packages/
│   └── shared/                # 共享类型、常量、主题配置
└── package.json               # 根级 workspace 配置
```

---

## 🚀 快速开始

本项目使用 NPM Workspaces。在仓库根目录执行一次 `npm install` 即可装好所有 workspace 依赖。

### 1. 安装依赖

```bash
npm install
```

### 2. 启动后端服务

```bash
npm run server:dev
# 服务运行在 http://localhost:3000
```

### 3. 启动移动端

**原生(iOS / Android)**:

```bash
npm run mobile:start
# 扫码或使用模拟器打开
```

**网页端(Web)**:

```bash
cd apps/mobile
npx expo start --web
# 默认打开 http://localhost:8081
```

### 4. 演示账号

- **邮箱**: `demo@example.com`
- **密码**: `demo123`

> 💡 前端默认连到 `http://localhost:3000/api`。如果后端部署在其他地址,请修改 `apps/mobile/src/services/api.ts` 中的 `API_BASE_URL`。

---

## 📡 API 接口一览

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/health` | 健康检查 |
| POST | `/api/auth/register` | 用户注册 |
| POST | `/api/auth/login` | 用户登录 |
| GET | `/api/auth/me` | 获取当前用户 |
| GET | `/api/records` | 获取记录列表 |
| POST | `/api/records` | 创建记录 |
| PUT | `/api/records/:id` | 更新记录 |
| DELETE | `/api/records/:id` | 删除记录 |
| GET | `/api/records/summary` | 获取统计摘要 |
| POST | `/api/parse` | AI 智能解析文本 |
| GET | `/api/categories` | 获取类别列表 |
| POST | `/api/categories` | 创建自定义类别 |
| GET | `/api/families` | 获取家庭列表 |
| POST | `/api/families` | 创建家庭 |
| POST | `/api/families/join` | 加入家庭 |
| GET | `/api/families/:id/stats` | 家庭统计 |
| GET | `/api/budgets` | 获取预算 |
| POST | `/api/budgets` | 设置预算 |
| GET | `/api/export/csv` | 导出 CSV |
| GET | `/api/export/share-data` | 获取分享数据 |

---

## 🤖 AI 智能解析示例

| 输入文本 | 解析结果 |
|----------|----------|
| "今天午饭花了35块" | 金额: 35, 类别: 餐饮, 类型: 支出 |
| "昨天打车回家30" | 金额: 30, 类别: 交通, 类型: 支出, 日期: 昨天 |
| "发工资15000" | 金额: 15000, 类别: 工资, 类型: 收入 |
| "买了杯咖啡25元" | 金额: 25, 类别: 餐饮, 类型: 支出 |
| "超市购物199" | 金额: 199, 类别: 购物, 类型: 支出 |

---

## 🎨 UI 设计规范

- **主色调**: 紫 `#6C5CE7` / 粉 `#FD79A8` / 绿 `#00B894`
- **辅助色**: 红 `#FF6B6B` / 黄 `#FDCB6E` / 蓝 `#74B9FF`
- **风格**: Instagram 风格，渐变背景，大圆角卡片，柔和阴影
- **字体**: 系统无衬线体

---

## 🗄️ 数据库模型

系统包含 6 个核心数据表：

1. **users** - 用户信息
2. **families** - 家庭群组（含邀请码）
3. **family_members** - 家庭成员关系（角色: admin/member/viewer）
4. **records** - 记账明细（金额、类别、日期、来源）
5. **categories** - 类别配置（14个系统默认 + 用户自定义）
6. **budgets** - 预算管理

---

## 📋 预置类别

### 支出类别
🍽️ 餐饮 | 🚗 交通 | 🛒 购物 | 🎮 娱乐 | 🏥 医疗 | 📚 教育 | 🏠 居住 | 📱 通讯 | 👔 服饰 | 📌 其他

### 收入类别
💰 工资 | 🎁 奖金 | 📈 投资 | 💵 其他收入

---

## 📄 License

MIT
